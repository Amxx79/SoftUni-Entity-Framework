﻿namespace Boardgames.Data.Models
{
    public enum CategoryType
    {
        Abstract,
        Children,
        Family, Party,
        Strategy
    }
}