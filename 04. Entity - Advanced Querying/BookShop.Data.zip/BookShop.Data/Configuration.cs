﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => "Server=DESKTOP-P0HOVAK;Database=BookShop;Integrated Security=True;";
    }
}
